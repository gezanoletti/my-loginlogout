=== Login Logou Plugin ===
Contributors: Nagarjun Sonti
Donate link:#
Tags: login, logout, redirect,switcher, wordpress login, wordpress logout, custom menubar, default menubar, menubar links, logout links, login links, login logout switcher, login logout redirect links, login logout redirect pages, else
Requires at least: 3.2
Tested up to: 3.9
Stable tag: 2.2
License: GPL2 or later


== Description ==

My Login/Logout plugin With this plugin you can now add a real log in/logout item menu with autoswitch when user is logged in or not.it works both Custom menubar as well as Default menubar.We have a flexibility to set custom redirect pages for login as well as logout. 
it works both custom menu bar as well as defult menu bar
= Extra Functions =
The user has a option  to set the custom redirect pages from selecting the drop down lists from  admin page.  



== Installation ==

1. Upload `my_login/logout.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the 'Settings' on admin sidebar Click the My Login/Logout.
4. Defult login/logout redirct pages are the index 
5. if you want to change Select the pages drop down list for login and logout redirection.


== Screenshots ==

1. defult menu bar with login/logout
2. Custom menu bar with login/logout
3. Setting the redirect pages on dashboard
== Frequently Asked Questions ==

= How do i use this plugin? =

Simple just follow the instructions for installation and remember to activate and thats it!
